<?php 

add_filter( 'elementor/icons_manager/additional_tabs', 'themesflat_iconpicker_register' );



function themesflat_iconpicker_register( $icons = array() ) {

	

	$icons['theme_icon_extend'] = array(

		'name'          => 'theme_icon_extend',

		'label'         => esc_html__( 'Saylo Icon', 'themesflat-elementor' ),

		'labelIcon'     => 'icon-saylo-developent',

		'prefix'        => '',

		'displayPrefix' => '',

		'url'           => THEMESFLAT_LINK_PLUGIN . 'css/icon-saylo.css',

		'fetchJson'     => URL_THEMESFLAT_ADDONS_ELEMENTOR_THEME . 'assets/css/saylo_fonts.json',

		'ver'           => '1.0.0',

	);

	$icons['theme_icon_extend_2'] = array(

		'name'          => 'theme_icon_extend_2',

		'label'         => esc_html__( 'Saylo Icon Extends', 'themesflat-elementor' ),

		'labelIcon'     => 'icon-saylo-maketing1',

		'prefix'        => '',

		'displayPrefix' => '',

		'url'           => THEMESFLAT_LINK_PLUGIN . 'css/icon-saylo1.css',

		'fetchJson'     => URL_THEMESFLAT_ADDONS_ELEMENTOR_THEME . 'assets/css/saylo1_fonts.json',

		'ver'           => '1.0.0',

	);



	return $icons;

}