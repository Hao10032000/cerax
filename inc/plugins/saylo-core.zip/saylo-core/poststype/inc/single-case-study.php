<?php

get_header(); 

?>

<div class="container">

	<div class="row">

		<div class="col-md-12">

			<div class="wrap-content-area">

				<div id="primary" class="content-area">	

					<main id="main" class="main-content" role="main">

						<div class="entry-content">	

							<?php while ( have_posts() ) : the_post(); 
								global $post;
								// information
								$desc = get_post_meta($post->ID, 'desc_case_value', true);
								$client = get_post_meta($post->ID, 'client_case_value', true);
								$date = get_post_meta($post->ID, 'date_case_value', true);
								$duration = get_post_meta($post->ID, 'duration_case_value', true);
								$location = get_post_meta($post->ID, 'location_case_value', true);
							?>	

								<div class="content-top-infor">
									<div class="content-left">
										<?php if ( themesflat_get_opt('case_study_title_single') ) :?>	
											<h4 class="post-title"><?php the_title(); ?></h4>
										<?php endif;?>
										<?php if(!empty($desc)): ?>
											<p><?php echo wp_kses_post($desc);  ?></p>
										<?php endif;?>
									</div>
									<div class="content-right">
										<div class="featured-post"><?php the_post_thumbnail('themesflat-service-single'); ?></div>
									</div>
								</div>

								<ul class="bottom-infor">
									<?php if(!empty($client)): ?>
										<li>
											<p><?php esc_html_e('Clients', 'themesflat-core') ?></p>
											<h5><?php echo $client; ?></h5>
										</li>
									<?php endif;?>
									<?php if(!empty($date)): ?>
										<li>
											<p><?php esc_html_e('Start Date', 'themesflat-core') ?></p>
											<h5><?php echo $date; ?></h5>
										</li>
									<?php endif;?>
									<?php if(!empty($duration)): ?>
										<li>
											<p><?php esc_html_e('Duration:', 'themesflat-core') ?></p>
											<h5><?php echo $duration; ?></h5>
										</li>
									<?php endif;?>
									<?php if(!empty($location)): ?>
										<li>
											<p><?php esc_html_e('Location:', 'themesflat-core') ?></p>
											<h5><?php echo $location; ?></h5>
										</li>
									<?php endif;?>
										<li>
											<p><?php esc_html_e('Service:', 'themesflat-core') ?></p>
											<h5><?php echo esc_attr ( the_terms( get_the_ID(), 'case_study_category', '', ', ', '' ) ); ?></h5>
										</li>
								</ul>






								

								<?php the_content(); ?>


								<?php themesflat_post_navigation_postype(); ?>

						

							<?php endwhile; // end of the loop. ?>

						</div><!-- ./entry-content -->

					</main><!-- #main -->

				</div><!-- #primary -->

			</div>

		</div>

	</div>

</div>



<?php get_footer(); ?>