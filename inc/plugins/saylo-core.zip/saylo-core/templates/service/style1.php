<div class="item">				

    <div class="services-post">


        <div class="content"> 

            <?php if(!empty($icon)): ?>
                <div class="icon">
                    <?php echo $icon; ?>
                </div>
            <?php endif; ?>

            <h5 class="title border_eff">

                <a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a>

            </h5>

            <?php if ( $settings['show_exc'] == 'yes' ): ?>

                <p class="description"><?php echo wp_trim_words( get_the_content(), $settings['excerpt_lenght'], '' ); ?></p>

            <?php endif; ?>

            <?php if ( $settings['show_button'] == 'yes' ): ?>

                <div class="tf-button-container">

                <a href="<?php echo esc_url( get_permalink() ) ?>" class="tf-button">

                    <span><?php echo esc_html( $settings['button_text'] ); ?></span>

                    <?php echo \Elementor\Addon_Elementor_Icon_manager_saylo::render_icon( $settings['post_icon_readmore'], [ 'aria-hidden' => 'true' ] );?>

                </a>

                </div>

            <?php endif; ?>

        </div>

    </div>

</div>